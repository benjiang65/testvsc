
## Merchandising and inventory

Strategically plan merchandising and inventory to increase sales and profitability. Before you can offer products for sale in your retail channels, you must create and configure the products in Commerce. You can create the products, define the product properties and attributes, and assign the products to retail category hierarchies. To make the products available to your retail channels and add them to an active assortment, you must release the products to the legal entities where they are available.

You can make price adjustments to products or set up discounts that are applied to a line item or a transaction across all of your sales channels.

## Channel management

As you plan your Commerce experience, you will decide how to define and configure your stores, which can be brick-and-mortar stores, online stores, or call centers.

Each store can have its own payment methods, delivery methods, price groups, income and expense accounts, registers, and staff. After you create your store, you create an assortment of products that you want the store to carry. You can also define store-specific prices and discounts that apply to products that are available in the store.

The screenshot below shows the Channel deployment screen.

![screenshot of Channel deployment screen](../media/m14-channel.png)


## E-Commerce

Streamline your business with a commerce solution that scales to your needs while engaging at all points traditional and emerging channels. Set up storefronts, manage content, and create catalogs of products for better sale experiences.

Users can easily create layouts and templates with built-in web authoring and development tools. Rules and default content can be reused across a wide range of pages. Quickly enhance pages through themes along with page enhancements to give depth and richness to customer experience. Enable seamless management of catalogs, content, assets, promotions, inventory, and pricing across all channels 

## Commerce deployment

Create and deploy retail customizations in one combined package. Whether working in the cloud or on-premises, move your customizations and deploy them across various environments together.

Dynamics 365 Commerce gives you multiple options for package deployment. Incorporate mobile capabilities, while deploying all customizations as a single retail deployable package. Separate packages for individual components, such as Cloud POS, Score Scale Unite, Cloud Scale Units, and mobile considerations, are packaged as a single retail deployable package.

Next, let's take a look at Dynamics 365 Fraud Protection.