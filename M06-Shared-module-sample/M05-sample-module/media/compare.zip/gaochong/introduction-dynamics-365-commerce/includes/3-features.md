The following list represents some of the key functionalities that Dynamics 365 Commerce offers:

- **Unified commerce**: your organizations can create seamless shopping experiences across stores, web, mobile, and call centers.

- **Modern Point of Sale (MPOS)**: MPOS is a POS app for PCs, tablets, and phones. With MPOS, your sales staff can easily process transactions and orders from any device.

- **Merchandise management**: You can create and configure your product catalog before offering items from it for sale.

- **Customer loyalty**: You can track your customers' trends and habits, send personalized notifications and offers that make shopping in your channels easier.

Let's take them one by one.

### Unified commerce

Retail organizations are no longer just brick and mortar stores. They need the ability to unify the shopping experience across all retail experiences. They need to support different types of stores, including not just the traditional brick-and-mortar store, but also online stores, or even call centers. Each retail store can have its own payment methods, delivery methods, price groups, income and expense accounts, registers, and staff. But across all the purchasing channels, the retail organization can provide customers the convenience and flexibility to buy-in store, pick up in other locations, or get home delivery through optimized ordering and fulfillment tools.

### Point of Sale (POS)

Support and manage your Point of Sale experiences with Dynamics 365 Commerce. Configure your operations across stores and online, while enabling intelligent product and inventory search tools. Create buttons for functional actions, process sales, and manage receipts after the sale is completed.

Dynamics 365 Commerce supports both Cloud and MPOS Point of Sale experiences. Use the Cloud POS on browsers within mobile devices, or use the MPOS to process sales, orders, operations, and inventory across PC’s, tablets, and phones.  Track and control commissions and receipts during and after sale events. 

With Dynamics 365 Commerce, Modern Point of Sale (MPOS) and Cloud POS can use a wide range of hardware peripherals. Both MPOS and Cloud POS offer multiple interfaces and deployment options to help you with your various business scenarios. The virtual peripheral simulator primarily supports testing of scenarios that usually require physical POS peripheral devices. The peripheral simulator includes both a virtual peripheral simulator and a POS simulator and lets you test the compatibility of physical peripheral devices without having to deploy the POS client.

### Merchandising and inventory

Strategically plan your merchandising and inventory to increase sales and profitability. Before you can offer products for sale in your retail channels, you must create and configure the products in Commerce. You can create the products, define the product properties and attributes, and assign the products to retail category hierarchies. To make the products available to your retail channels and add them to an active assortment, you must release the products to the legal entities where they are available.

You can make price adjustments to products, and can also set up discounts that are applied to a line item or a transaction at the POS, in a call center sales order, or in an online order.

The screenshot below shows the Category and product management screen.

![screenshot of Category and product management screen](../media/m14-merchandising.png)


### Customer loyalty

Loyalty programs can help increase customer loyalty by rewarding customers for their interactions with your brand. In Dynamics 365 Commerce, you can set up simple or complex loyalty programs that apply across your legal entities in any retail channel. 

Set up loyalty programs that represent the different reward incentives that you offer. Define earning rules to identify the activities that a customer must complete to earn rewards. Issue loyalty cards from any retail channel that participates in your loyalty programs, and link loyalty cards to one or more loyalty programs that the customer can participate in. You can also link a customer record to a loyalty card, so that the customer can pool loyalty points from multiple cards and redeem them.


The screenshot below shows the loyalty points a customer has accumulated.

![customer record in Commerce showing loyalty points accumulated](../media/m14-d365-commerce-window.png)
 

Assisted selling in Commerce works seamlessly across tablets and phone while harnessing the power of the cloud. Create product recommendations across e-commerce and point of sale experiences. As customers interact with your store, they can build up loyalty programs, which creates loyal return customers. Finally, give your customers the ability to leave reviews and ratings so you can improve your processes for the future

Now let's turn our attention to other Dynamics 365 Commerce capabilities.