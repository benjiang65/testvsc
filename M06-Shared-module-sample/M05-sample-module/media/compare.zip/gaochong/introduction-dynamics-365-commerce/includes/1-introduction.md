Customer shopping is no longer limited to a moment in time. Engagement starts well before customers reach your store or website, and the nature of our interaction with customers has also changed. 

Customers are no longer looking to sales associates for product details. Rather, they engage retailers when they are already significantly down the track of the purchase journey. 

This shift is accompanied by a new expectation from customers that their purchasing experience needs to be personalized, engaging, and friction free. This experience is only possible by bringing together digital and physical shopping channels. Only then can you deliver the personalized and differentiated experiences that give you a competitive edge and build brand loyalty. 


The graphic below shows the components of Dynamics 365 Commerce.

![Graphic showing the components of Dynamics 365 Commerce](../media/m14-d365-commerce.png)

Connected Commerce is not just about delivering great customer experiences. By bringing together historically disconnected channels like physical stores, e-commerce, call centers and emerging channels, you can break down the data silos traditional retail businesses have been operating under. This in turn enables you to utilize modern tools like machine learning and artificial intelligence to gain better business insights. You can drive an intelligent supply chain, empower your employees, and deliver experiences that were not possible a decade ago. 

|  |  |
| ------------ | ------------- | 
| ![Icon indicating play video](../media/video-icon.png) | Watch this video to see how we will explore Dynamics 365 Commerce and the value it brings to your business. |
 
> [!VIDEO https://www.microsoft.com/videoplayer/embed/RE4dspC]

In this module, you will:

 * Discover deployment options.

 * Learn about point of sales systems.

 * Explore omnichannel and merchandizing.

Next, we will take at the challenges faced by retail organizations and how Dynamics 365 Commerce can help address those challenges.

Let's start with on overview of Dynamics 365 Commerce.
